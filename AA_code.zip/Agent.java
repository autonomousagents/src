
public interface Agent {

	public void doMove(Position other);
	
	public Position getPos();

}
